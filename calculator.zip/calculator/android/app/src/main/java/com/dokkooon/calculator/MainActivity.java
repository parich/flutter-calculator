package com.dokkooon.calculator;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
